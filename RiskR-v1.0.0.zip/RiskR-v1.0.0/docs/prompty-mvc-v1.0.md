# RiskR 1.0 — inżynieria promptów i MVC

**Zespół:** Mateusz Zyra i Adam Wójciak.

**Narzędzie:** Codex.

**Data pracy:** 25.11.2026.

Poniżej zapisano zlecenia opisujące wykonane etapy, decyzje i zaobserwowane wyniki. Są to uporządkowane specyfikacje pracy w tej sesji, nie transkrypcje osobnych rozmów obu członków zespołu.

## 1. Prompt ogólny i doprecyzowanie

**Wersja ogólna:**

> Zrób RiskR w MVC i popraw aplikację.

Taki prompt nie wskazuje istniejących funkcji, plików, ograniczeń ani sposobu oceny. Może doprowadzić do zastąpienia aplikacji nowym projektem, zmiany bazy albo dodania funkcji spoza MVP.

**Wersja precyzyjna:**

> Kontekst: RiskR działa lokalnie na Windows 11 w Pythonie 3.12, Flask, Jinja i SQLite. app.py zawiera konfigurację oraz trasy; riskr/engine.py reguły i runner; riskr/db.py połączenia i schemat. Widoki W01–W03 są w templates. Zadanie: rozdziel istniejący kod według MVC, bez zmiany zakresu F01–F05. Ograniczenia: zachowaj dane, adresy URL, mechanizm CSRF, parametry awarii i jeden aktywny eksperyment. Nie dodawaj logowania, wykresów historii ani raportów. Wynik: kontroler Blueprint, model niezależny od Flask i szablony bez dostępu do SQL. Sprawdzenie: dotychczasowe testy, poprawny i błędny przypadek każdej funkcji, restart serwera i przejście W01 → W02 → W03.

**Różnica:** precyzyjna wersja podaje cel, stan wejściowy, granice zmiany i mierzalne kryteria. Ogólna wersja służyła porównaniu sposobu formułowania poleceń; nie wykonano na jej podstawie odrębnej implementacji.

## P1 — plan MVP i mapa MVC

**Kontekst:** lokalna aplikacja RiskR z laboratorium 03; istniejące F01–F05, W01–W03, tabele environment, service, experiment i measurement. Materiały wejściowe: `docs/roadmap-v1.md`, `docs/technologie.md`, `app.py`, `riskr/engine.py`, `riskr/db.py`, szablony i testy.

**Zadanie:**

> Przygotuj plan wykorzystania istniejącego kodu z podziałem na model, widoki i kontroler. Dla F01–F05 wskaż pliki i warunki poprawności. Oddziel model od Flask i przenieś SQL z funkcji home do modelu. Zaproponuj Blueprint oraz osobny schema.sql. Na tym etapie zapisz plan zmian, bez przebudowy funkcji.

**Ograniczenia:** ten sam stos, baza i adresy URL; lokalne demo; bez F06–F08.

**Wynik:** mapa plików, przepływ F03 i kolejność małych zmian w [architektura-mvc.md](architektura-mvc.md).

**Sprawdzenie i rzeczywisty rezultat:** porównano plan z mapą MVP. Wyjściowy zestaw 16 testów zakończył się powodzeniem. Plan zapisano w commicie `2b477a2`; stan wejściowy aplikacji w `973eeb2`.

## P2 — działający szkielet MVC

**Kontekst:** plan P1 oraz istniejące pliki aplikacji.

**Zadanie:**

> Przenieś implementację Engine do ExperimentModel w riskr/models/experiment.py, a obliczenia pomiarów do models/metrics.py. Zachowaj alias Engine dla wcześniejszych importów. Trasy, obsługę formularzy i odpowiedzi umieść w riskr/controllers/experiments.py jako Blueprint riskr. App.py ma tworzyć aplikację i rejestrować Blueprint. Model udostępnia drafts() zamiast SQL w kontrolerze. Wydziel schema.sql i popraw url_for w szablonach. Najpierw uruchom W01 oraz zapis i ponowny odczyt szkicu W02.

**Ograniczenia:** zachowanie danych i publicznych adresów; brak kopiowania logiki modelu do kontrolera.

**Wynik:** pliki w `riskr/models`, `riskr/controllers`, `riskr/schema.sql` oraz krótszy `app.py`; zależności i polecenia startu bez zmian.

**Sprawdzenie i rzeczywisty rezultat:** `test_views_and_draft_roundtrip` przeszedł. W01 otrzymuje dane przez model; szkic zapisuje się i pozostaje po ponownej inicjalizacji. Szkielet i test F01 zapisano w `92f8e4d`.

## P3 — funkcje MVP sprawdzane osobno

Funkcje istniały przed refaktoryzacją. Każde zlecenie obejmuje zachowanie konkretnej funkcji w MVC oraz sprawdzenie ścieżki HTTP → model → baza, zamiast ponownego implementowania tej samej logiki.

### P3.1 — F01: środowisko

**Kontekst:** `controllers/experiments.py`, `models/experiment.py`, `laboratory.py`, W01.

> Zadanie: sprawdź wyłącznie F01 przez kontroler. GET /api/environment ma pokazywać demo-api i demo-worker oraz gotowość. Próba zapisania zewnętrznego URL-a zamiast usługi ma dać HTTP 400; niedostępne laboratorium ma blokować start kodem 409. Ograniczenia: nie dodawaj nowych celów ani nie oznaczaj loopback jako izolacji systemowej. Wynik: test poprawnego i błędnego przypadku. Sprawdzenie: uruchom test mvc_f01 i zachowaj wynik w Git.

**Rezultat:** oba cele i ograniczenie zakresu potwierdzone; obce cele oraz start niedostępnego laboratorium odrzucone. Test przeszedł; commit `92f8e4d`.

### P3.2 — F02: scenariusze

**Kontekst:** katalog SCENARIOS, model walidacji i API zapisu.

> Zadanie: sprawdź zapis i odczyt HTTP 500/100%, latency/500 ms, overload/20 żądań/s i unavailability/100%. Błędny typ other ma być odrzucony kodem 400. Ograniczenia: jeden typ zakłócenia w eksperymencie, parametryzowane SQL, zachowanie F01. Wynik: test mvc_f02. Sprawdzenie: zapisany typ i intensywność są zgodne z wejściem, a zły typ nie jest przyjęty.

**Rezultat:** wszystkie cztery typy zapisano i odczytano; błędny typ odrzucono. Test przeszedł; commit `7c9eec9`.

### P3.3 — F03: konfiguracja

**Kontekst:** formularz W02 i metoda modelu save().

> Zadanie: sprawdź POST formularza dla demo-api, latency, 500 ms, 30 s oraz czas błędny 301 s. Kontroler ma przekazać dane modelowi i pokazać komunikat lub przekierowanie. Ograniczenia: zachowaj token CSRF i pola formularza; reguły pozostają w modelu. Wynik: test mvc_f03. Sprawdzenie: poprawny szkic wraca po ponownej inicjalizacji bazy; dla 301 s formularz pokazuje błąd i nie powstaje dodatkowy rekord.

**Rezultat:** przekierowanie i komunikat zapisu działają; błędne dane zwróciły HTTP 400. Test przeszedł; commit `396f130`.

### P3.4 — F04: start i stop

**Kontekst:** metody modelu start()/stop() i odpowiadające im trasy API.

> Zadanie: sprawdź uruchomienie szkicu na 20 s i ręczny stop przez kontroler. Stop szkicu przed startem oraz ponowny start zakończonego testu mają zwracać 409; nieistniejący identyfikator ma zwracać 404. Ograniczenia: nie zmieniaj runnera, limitów i automatycznego końca. Wynik: test mvc_f04. Sprawdzenie: po stopie stan stopped jest zapisany w modelu, a nie tylko pokazany w interfejsie.

**Rezultat:** operacje poprawne i błędne zwróciły przewidziane odpowiedzi. Test przeszedł; commit `be78d0c`.

### P3.5 — F05: pomiary

**Kontekst:** snapshot(), agregacja i kontroler pomiarów.

> Zadanie: uruchom krótki test HTTP 500, odczytaj pomiary przez API i sprawdź liczniki oraz dostępność. Przed startem oczekuj latest=null; dla nieistniejącego testu kodu 404. Ograniczenia: nie zastępuj braku danych zerem i nie zakładaj, że ostatnia odpowiedź musi być błędem po wygaśnięciu zakłócenia. Wynik: test mvc_f05. Sprawdzenie: w przebiegu występuje HTTP 5xx, a dostępność każdego okna odpowiada licznikom jego prób i sukcesów.

**Rezultat:** początkowe oczekiwanie „ostatnie okno ma 0%” zwróciło `AssertionError: 100.0 != 0`. Ostatnia sonda może zakończyć się już bez zakłócenia, dlatego doprecyzowano prompt i sprawdzanie każdego okna według liczników. Poprawiony test przeszedł; commit `f98920d`.

## P4 — diagnoza i poprawka na podstawie dowodów

**Prompt zbyt ogólny:** „Popraw walidację API”. Nie wskazuje konkretnej awarii ani warunków odbioru.

**Poprawiony prompt:**

> Kontekst: RiskR po refaktoryzacji MVC, Windows 11, Python 3.12.14 i Flask 3.1.3. Pliki: riskr/models/experiment.py, riskr/controllers/experiments.py, tests/test_riskr.py. Uruchomienie testu: python -m unittest discover -s tests -k mvc_invalid_json -v. Zadanie: napraw obsługę błędnych typów JSON w modelu. Kroki: wyślij POST /api/experiments z poprawnymi service_id, intensity i duration_seconds, ale fault_type jako [] albo {}; następnie sprawdź id jako [], {} i true. Oczekiwane: HTTP 400 z komunikatem i brak rekordu. Faktyczne: TypeError: unhashable type: 'list' lub 'dict'; puste listy i obiekty id są traktowane jak brak identyfikatora i tworzą szkic kodem 201. Ograniczenia: najmniejsza zmiana w modelu, bez przenoszenia walidacji do kontrolera, bez zmiany bazy i poprawnych operacji. Wynik: sprawdzenie typów danych oraz test regresyjny. Sprawdzenie: wadliwe dane dają 400, baza pozostaje pusta, następnie przechodzą wcześniejsze testy F01–F05 i restartu.

**Przyczyna:** operator wyszukiwania klucza słownika SCENARIOS otrzymywał niehashowalny typ, a `if identifier` nie odróżniał braku identyfikatora od pustej kolekcji.

**Zmiana:** model sprawdza obiekt konfiguracji, tekstowe typy usługi i scenariusza oraz typ i niepustość podanego identyfikatora przed operacją na bazie. Kontroler nadal tylko przekazuje dane i wybiera odpowiedź.

**Wynik przed:** jeden test z podprzypadkami zakończył się czterema nieudanymi asercjami i dwoma błędami; powstały dwa niepożądane szkice.

**Wynik po:** ten sam test przeszedł; sześć zestawów błędnych danych odrzucono, baza pozostała pusta. Pełny zestaw zakończył się wynikiem **22/22**. Poprawka: commit `07bbadc`.

## Odbiór lokalnej wersji

W przeglądarce wykonano W01 → W02 → zapis szkicu → uruchomienie → W03 → automatyczny koniec. Dla HTTP 500, 100%, 3 s otrzymano trzy odpowiedzi 5xx, 0% dostępności i stan „Zakończony”. Dane i identyfikator pochodziły z modelu i SQLite. Wyniki, logi i zakres niewykonanych sprawdzeń: [testy-v1.0.md](testy-v1.0.md).
