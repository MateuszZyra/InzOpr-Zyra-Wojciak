# RiskR 1.0 — architektura MVC

**Zespół:** Mateusz Zyra i Adam Wójciak.

## Cel i zakres

MVP oznacza minimalną użyteczną wersję produktu, a MVC określa podział kodu na model, widok i kontroler. RiskR zachowuje funkcje F01–F05 z mapy: lokalne laboratorium demonstracyjne, wybór zakłócenia, konfigurację, start i stop oraz pomiary na żywo. Stos pozostaje bez zmian: Python, Flask, Jinja, SQLite i Waitress.

## Plan małych zmian

1. Zapisać stan początkowy i sprawdzić dotychczasowe 16 testów.
2. Przenieść reguły oraz runner z `riskr/engine.py` do `riskr/models/experiment.py`, pozostawiając zgodny import starej nazwy.
3. Wydzielić trasy do Blueprint w `riskr/controllers/experiments.py`; usunąć zapytania SQL z warstwy HTTP.
4. Umieścić definicję bazy w `riskr/schema.sql`; zachować dane i dotychczasową inicjalizację.
5. Zaktualizować nazwy endpointów w szablonach, zachowując adresy URL i wygląd W01–W03.
6. Osobno zweryfikować F01–F05 przez kontroler i model, zapisując każdy etap w Git.
7. Przeprowadzić przegląd błędnych danych, testy regresji, restart i główną ścieżkę w przeglądarce.

## Mapa plików

| Rola | Pliki | Odpowiedzialność |
|---|---|---|
| Uruchomienie | `app.py` | Konfiguracja Flask, stworzenie modelu, rejestracja Blueprint, polecenia startu i inicjalizacji. |
| Kontroler C | `riskr/controllers/experiments.py` | Odczyt formularza lub JSON, wywołanie modelu, status HTTP, wybór szablonu i przekierowanie. Ochrona CSRF i prezentacja błędów żądań. |
| Model M | `riskr/models/experiment.py` | Walidacja parametrów, odczyt i zapis eksperymentów, kontrola aktywności, runner, pomiary, zakończenie i sprzątanie. Bez zależności od Flask. |
| Model M | `riskr/models/metrics.py` | Agregacja pomiarów i obliczenie wskaźników. |
| Widoki V | `templates/base.html`, `home.html`, `configure.html`, `monitor.html`, `error.html` | Układ, formularze, nawigacja oraz komunikaty. Nie wykonują SQL. |
| Widoki V | `static/style.css`, `static/app.js` | Wygląd, dopasowanie pól i odświeżanie pomiarów; walidacja w przeglądarce nie zastępuje modelu. |
| Infrastruktura | `riskr/db.py`, `riskr/schema.sql` | Połączenie SQLite, transakcje, FK i idempotentne tworzenie struktury. |
| Infrastruktura | `riskr/laboratory.py` | Wbudowane usługi HTTP i kontrolowane zakłócenia na loopback. |
| Zgodność importów | `riskr/engine.py` | Eksport dotychczasowej nazwy `Engine` jako aliasu modelu; bez powielania implementacji. |

We Flask funkcje obsługujące adresy nazywane są „view functions”; w tym podziale pełnią rolę kontrolera. Widokiem są szablony HTML i ich prezentacja w przeglądarce.

## Funkcje i warunki poprawności

| Funkcja | Model | Kontroler | Widok | Warunek odbioru |
|---|---|---|---|---|
| F01 | `readiness()` | `home()`, `environment()` | W01 / `home.html` | Wbudowane usługi są dostępne; cel zewnętrzny i niedostępne laboratorium blokują start. |
| F02 | `SCENARIOS`, `validate()` | `configure()`, `save()` | W02 / `configure.html` | Cztery typy dają się zapisać; nieznany typ jest odrzucony. |
| F03 | `save()`, `get()`, `drafts()` | `configure()`, `save()` | W01 i W02 | Poprawny szkic jest zapisany i ponownie odczytany, błędne dane nie tworzą rekordu. |
| F04 | `start()`, `stop()`, `_run()` | `configure()`, `start()`, `stop()` | W02 i W03 | Jeden aktywny eksperyment, stop i koniec czasu usuwają zakłócenie, błędna operacja ma czytelny komunikat. |
| F05 | `snapshot()`, `_persist()`, `aggregate()` | `monitor()`, `snapshot()` | W03 / `monitor.html` | Bieżące pomiary mają poprawne wartości, a brak danych jest odróżniony od 0% dostępności. |

## Przepływ F03 — zapis konfiguracji

```mermaid
sequenceDiagram
    actor U as Użytkownik
    participant V as W02 / configure.html
    participant C as Blueprint / configure()
    participant M as ExperimentModel.save()
    participant D as SQLite
    U->>V: Usługa, scenariusz, intensywność, czas
    V->>C: POST /experiments/new + token CSRF
    C->>M: Dane formularza i opcjonalne ID szkicu
    M->>M: Walidacja typów, zakresów i statusu
    alt Dane poprawne
        M->>D: Parametryzowany INSERT albo UPDATE
        D-->>M: Zapisany rekord
        M-->>C: Konfiguracja ze statusem draft
        C-->>V: Przekierowanie do szkicu i komunikat
    else Dane błędne
        M-->>C: RuleError
        C-->>V: Formularz z zachowanymi polami i błędem
    end
```

Przykład poprawny: `demo-api`, `latency`, 500 ms, 30 s → rekord `draft`. Przykład błędny: czas 301 s → komunikat „Czas trwania musi wynosić od 1 do 300 s” i brak zapisu. Odpowiedzialność za zakres wartości należy do modelu, więc obowiązuje zarówno formularz, jak i API.

## Dane i zgodność

Refaktoryzacja nie zmienia schematu tabel ani położenia domyślnej bazy. `CREATE TABLE IF NOT EXISTS` i `INSERT OR IGNORE` zachowują zapisane konfiguracje i pomiary. Adresy `/`, `/experiments/new`, `/experiments/<id>` i `/api/...` pozostają takie same; wewnętrzne nazwy endpointów otrzymują prefiks `riskr.`.

## Ograniczenia i założenia

- Jeden proces runnera i jeden lokalny użytkownik, bez logowania.
- F01 ogranicza cele do wbudowanych usług; nie jest dowodem izolacji systemowej. Docker pozostaje osobnym wariantem wymagającym uruchomienia.
- F06–F08 pozostają poza zakresem: brak wykresów historii, porównania faz i raportów.
- Testy na drugim komputerze, aktualizacja LaboChat i commit drugiego członka zespołu wymagają rzeczywistego wykonania przez tę osobę.

Materiały: [Flask — Blueprints](https://flask.palletsprojects.com/en/stable/blueprints/), [MDN — MVC](https://developer.mozilla.org/en-US/docs/Glossary/MVC).
