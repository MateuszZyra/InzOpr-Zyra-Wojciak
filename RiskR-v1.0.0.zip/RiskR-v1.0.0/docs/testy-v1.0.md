# RiskR 1.0 — testy MVC i odbiór lokalny

**Zespół:** Mateusz Zyra i Adam Wójciak.

**Weryfikacja:** 25.11.2026, Windows 11, Python 3.12.14, Flask 3.1.3, SQLite 3.53.1, Waitress 3.0.2.

## Wynik ogólny

**22 testy automatyczne: działa.** Czas końcowego wykonania: 39,987 s. Log: [testy-v1.0-automatyczne.txt](testy-v1.0-automatyczne.txt). W zestawie znajdują się dotychczasowe 16 testów, pięć testów ścieżek MVC F01–F05 i test regresyjny błędnych typów JSON.

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Testy tworzą oddzielne bazy pod `tmp`, używają lokalnych serwerów HTTP i nie zmieniają roboczej bazy. Restart sprawdzany jest przez rzeczywiste przerwanie oraz ponowne uruchomienie procesu serwera.

## Sprawdzenia kolejnych etapów

| Etap | Przypadek poprawny | Przypadek błędny | Rzeczywisty wynik | Status |
|---|---|---|---|---|
| Stan początkowy | Dotychczasowe funkcje i zapis | Dotychczasowe testy walidacji, konfliktów i sprzątania | 16/16 testów przed zmianami | działa |
| P2: szkielet | W01, formularz W02, zapis i odczyt szkicu | Przekierowanie szkicu zamiast monitorowania nieuruchomionego testu | Widoki odpowiedziały; dane przetrwały ponowną inicjalizację | działa |
| F01 | GET /api/environment, dwie dostępne usługi | Zewnętrzny cel; start niedostępnego laboratorium | Gotowość potwierdzona; błędy 400 i 409, szkic zachowany | działa |
| F02 | Zapis czterech typów i odczyt parametrów | Nieznany typ other | Cztery poprawne odpowiedzi 201; błędny typ 400 | działa |
| F03 | Formularz latency/500 ms/30 s i ponowny odczyt | Czas 301 s | Przekierowanie i zapis; komunikat 400 bez dodatkowego rekordu | działa |
| F04 | Start na 20 s i stop przez API | Stop przed startem, start zakończonego testu, brak ID w bazie | `stopped`; błędne operacje 409/404 | działa |
| F05 | Pomiar HTTP 500 i dostępność wyliczona z liczników | Brak pomiarów i nieistniejący eksperyment | Błędy 5xx zapisane, obliczenia zgodne; `latest=null` albo 404 | działa |
| P4: typy JSON | Dotychczasowy poprawny formularz i JSON | Kolekcje zamiast typu zakłócenia lub ID, ID jako bool | Wszystkie sześć wadliwych zestawów: 400, brak szkiców | działa |
| Trwałość | Szkic i pomiary po ponownym starcie | Przerwanie procesu podczas eksperymentu | Dane zachowane; test oznaczony `failed`, brak starego zakłócenia | działa |
| Współbieżność | Jeden aktywny eksperyment | Równoczesny drugi start i druga blokada runnera | Jeden start przyjęty, drugi odrzucony | działa |
| Bezpieczeństwo formularzy | Poprawny token CSRF | Brak CSRF i obcy Origin | Żądania bez uprawnionego kontekstu odrzucone kodem 403 | działa |
| Sprzątanie | Automatyczny koniec i powtórny stop | Kontrolowany wyjątek usuwania zakłócenia | `cleanup_failed`, blokada kolejnego startu i poprawne ponowienie | działa |

Funkcje istniejące przed MVC nie zostały napisane ponownie; testy etapowe potwierdzają ich działanie po zmianie organizacji kodu.

## Ocena rozdziału MVC

| Sprawdzenie kodu | Zaobserwowany wynik |
|---|---|
| SQL w kontrolerze i app.py | Nie występuje; odczyt szkiców przeniesiono do modelu. |
| Zależność modelu od Flask | Nie występuje; model nie odczytuje request i nie renderuje szablonów. |
| Adresy i endpointy | Publiczne ścieżki zachowane, nazwy endpointów mają prefiks riskr. |
| Schemat i dane | Definicje przeniesione do schema.sql bez zmiany tabel. |
| Powielanie kodu | Stary Engine jest aliasem ExperimentModel, bez drugiej implementacji. |

To wynik przeglądu kodu. Działanie HTTP i bazy potwierdzają osobno testy wykonawcze.

## Błędy i zmiana wyniku

### B01 — błędne założenie testu ostatniego okna

Test F05 zakładał 0% dostępności w ostatnim oknie po eksperymencie HTTP 500. Rzeczywisty wynik wyniósł 100%, ponieważ końcowa sonda może zakończyć się po wygaśnięciu zakłócenia. Błąd dotyczył oczekiwania testu: `AssertionError: 100.0 != 0`. Po doprecyzowaniu sprawdzenie wymaga zarejestrowania błędów w przebiegu i poprawnego procentu wynikającego z liczników każdego okna. Wynik po korekcie: **działa**.

### B02 — niepoprawne typy JSON

Przed poprawką `fault_type: []` i `fault_type: {}` powodowały `TypeError: unhashable type`. Puste kolekcje w `id` były traktowane jako brak identyfikatora i tworzyły rekord kodem 201. Test przed zmianą zakończył się czterema nieudanymi asercjami oraz dwoma błędami. Model uzupełniono o sprawdzenie typów przed wyszukiwaniem scenariusza i zapisem. Po zmianie wszystkie niepoprawne zestawy zwracają 400, a baza pozostaje pusta. Wynik po korekcie: **działa**.

Dowody: [log przed poprawką](mvc-p4-przed.txt), [log po poprawce](mvc-p4-po.txt). Opis doprecyzowania polecenia: [P4](prompty-mvc-v1.0.md#p4--diagnoza-i-poprawka-na-podstawie-dowodów).

## Sprawdzenie w przeglądarce

Uruchomienie: `python app.py run --port 5050 --database tmp/mvc-preview.sqlite3`.

1. W W01 wybrano `demo-api`; formularz W02 otworzył właściwą usługę.
2. Wybrano HTTP 500, 100%, 3 s i zapisano konfigurację; pojawił się komunikat powodzenia oraz identyfikator szkicu.
3. Uruchomiono szkic; przeglądarka przeszła do W03.
4. Po automatycznym końcu widniał status „Zakończony”, pozostały czas 0 i komunikat o usunięciu zakłócenia.
5. Zapisano trzy próby, trzy odpowiedzi HTTP 5xx, 0% dostępności i średni czas 135 ms.

**Status: działa.** [Zrzut ekranu](screenshots/mvc-v1.0.jpg) dokumentuje stan końcowy. Liczby są wynikiem tego konkretnego wykonania, nie stałymi oczekiwanymi dla każdego uruchomienia.

## Granice potwierdzenia gotowości

| Element odbioru | Status | Uzasadnienie |
|---|---|---|
| Lokalny wariant F01–F05, MVC i główny proces | działa | Testy oraz weryfikacja w przeglądarce. |
| Trwałość danych i odzyskanie po restarcie | działa | Test osobnego procesu. |
| Uruchomienie na komputerach obu członków zespołu | niewykonany | Dostęp do jednego stanowiska. |
| Wyjaśnienie architektury przez obie osoby | niewykonany | Opis przepływu przygotowany; nie przeprowadzono rozmowy z obiema osobami. |
| Izolacja Docker | niewykonany | Brak Dockera na stanowisku. F01 lokalnie ogranicza cele, lecz nie zapewnia izolacji systemowej. |
| Własny commit Adama Wójciaka | niewykonany | Commity zapisano przy użyciu istniejącej konfiguracji Git Mateusza Zyry; nie zmieniano autorstwa. |
| Publikacja GitHub i aktualizacja LaboChat | niewykonany | Brak wskazanego zdalnego repozytorium i połączonej przestrzeni. |

Oznaczenie `v1.0.0` dotyczy sprawdzonej lokalnej wersji demonstracyjnej. Nie potwierdza niewykonanych elementów odbioru zespołowego.
