import sqlite3
from .models.metrics import aggregate  # Zgodność dotychczasowych importów.
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime, timezone

SERVICES = ('demo-api', 'demo-worker')
ACTIVE = ('starting', 'running', 'stopping', 'cleanup_failed')


def now():
    return datetime.now(timezone.utc).isoformat(timespec='milliseconds')


@contextmanager
def connect(path):
    db = sqlite3.connect(path, timeout=10)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    try:
        yield db
        db.commit()
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()


def initialize(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.executescript(Path(__file__).with_name('schema.sql').read_text(encoding='utf-8'))
        db.execute("INSERT OR IGNORE INTO environment VALUES ('local','Lokalne laboratorium','unknown',0,NULL)")
        for name in SERVICES:
            db.execute('INSERT OR IGNORE INTO service VALUES (?,?,?,?,?,?)',
                       (name, 'local', name, 'loopback:/' + name, 'unknown', None))
