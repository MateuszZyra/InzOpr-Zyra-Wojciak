"""Obliczenia wskaźników na podstawie wyników sond HTTP."""

def aggregate(samples):
    responses = [s for s in samples if s['status'] is not None]
    return {
        'request_count': len(samples), 'response_count': len(responses),
        'http_5xx_count': sum(500 <= s['status'] < 600 for s in responses),
        'timeout_count': sum(s['error'] == 'timeout' for s in samples),
        'connection_error_count': sum(s['error'] == 'connection' for s in samples),
        'successful_count': sum(200 <= s['status'] < 400 for s in responses),
        'avg_response_ms': round(sum(s['elapsed_ms'] for s in responses) / len(responses), 2) if responses else None,
    }
