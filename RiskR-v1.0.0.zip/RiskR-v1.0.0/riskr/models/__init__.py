"""Modele danych i reguły biznesowe RiskR."""
