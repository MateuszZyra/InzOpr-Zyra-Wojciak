"""Zgodny import modelu dla kodu korzystającego z nazwy Engine."""
from .models.experiment import ExperimentModel, RuleError, SCENARIOS, validate

Engine = ExperimentModel
