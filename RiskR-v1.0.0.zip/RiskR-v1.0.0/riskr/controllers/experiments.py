"""Odbiór żądań i wybór odpowiedzi; reguły i SQL należą do modelu."""
import secrets
from urllib.parse import urlsplit

from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, session, url_for
from ..models.experiment import RuleError, SCENARIOS

bp = Blueprint('riskr', __name__)


def model():
    return current_app.extensions['model']


@bp.before_app_request
def protect():
    session.setdefault('csrf', secrets.token_urlsafe(32))
    if request.method == 'POST':
        origin = request.headers.get('Origin')
        if origin and urlsplit(origin).netloc != request.host:
            abort(403)
        token = request.headers.get('X-CSRF-Token') or request.form.get('csrf')
        if not token or not secrets.compare_digest(token, session['csrf']):
            abort(403)

@bp.after_app_request
def headers(response):
    response.headers['Cache-Control'] = 'no-store'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    return response

@bp.app_context_processor
def common():
    return dict(scenarios=SCENARIOS, csrf=session.get('csrf'),
                statuses={'draft':'Konfiguracja zapisana','starting':'Uruchamianie','running':'Trwa',
                          'stopping':'Zatrzymywanie','completed':'Zakończony','stopped':'Zatrzymany',
                          'failed':'Błąd','cleanup_failed':'Wymaga usunięcia zakłócenia'})

@bp.app_errorhandler(RuleError)
def rule_error(error):
    if request.path.startswith('/api/'):
        return jsonify(error=str(error)), error.code
    return render_template('error.html', message=str(error)), error.code

@bp.app_errorhandler(403)
def forbidden(error):
    message = 'Sesja wygasła lub żądanie pochodzi z innej strony. Odśwież widok i spróbuj ponownie.'
    if request.path.startswith('/api/'):
        return jsonify(error=message), 403
    return render_template('error.html', message=message), 403

@bp.app_errorhandler(404)
def missing(error):
    return render_template('error.html', message='Nie znaleziono strony.'), 404

@bp.get('/')
def home():
    state = model().readiness()
    drafts = model().drafts()
    return render_template('home.html', state=state, drafts=drafts, nav='home')

@bp.get('/health')
def health():
    return jsonify(model().health())

@bp.route('/experiments/new', methods=['GET','POST'])
def configure():
    values = dict(service_id=request.args.get('service_id','demo-api'), fault_type='latency', intensity=500, duration_seconds=30)
    identifier = request.args.get('draft')
    if identifier:
        values = model().get(identifier)
        if values['status'] != 'draft':
            return redirect(url_for('riskr.monitor', identifier=identifier))
    if request.method == 'POST':
        values = request.form.to_dict()
        identifier = values.get('id') or None
        try:
            row = model().save(values, identifier)
            identifier = row['id']
            if values.get('action') == 'start':
                model().start(identifier)
                return redirect(url_for('riskr.monitor', identifier=identifier))
            flash('Konfiguracja została zapisana. Możesz wrócić do niej po ponownym uruchomieniu aplikacji.', 'success')
            return redirect(url_for('riskr.configure', draft=identifier))
        except RuleError as exc:
            return render_template('configure.html', values=values, identifier=identifier, error=str(exc), nav='new'), exc.code
    return render_template('configure.html', values=values, identifier=identifier, nav='new')

@bp.get('/experiments/<identifier>')
def monitor(identifier):
    data = model().snapshot(identifier)
    if data['experiment']['status'] == 'draft':
        return redirect(url_for('riskr.configure', draft=identifier))
    return render_template('monitor.html', data=data, row=data['experiment'], nav='monitor')

@bp.get('/api/environment')
def environment():
    return jsonify(model().readiness())

def json_data():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        raise RuleError('Oczekiwano obiektu JSON.')
    return data

@bp.post('/api/experiments')
def save():
    data = json_data()
    return jsonify(model().save(data, data.get('id'))), 201

@bp.post('/api/experiments/<identifier>/start')
def start(identifier):
    return jsonify(model().start(identifier))

@bp.post('/api/experiments/<identifier>/stop')
def stop(identifier):
    return jsonify(model().stop(identifier))

@bp.get('/api/experiments/<identifier>')
def snapshot(identifier):
    return jsonify(model().snapshot(identifier))
