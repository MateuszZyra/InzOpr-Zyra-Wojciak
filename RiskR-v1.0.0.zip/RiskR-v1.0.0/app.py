import argparse
import atexit
import os
import secrets
from pathlib import Path

from flask import Flask
from riskr.db import initialize
from riskr.models.experiment import ExperimentModel
from riskr.controllers.experiments import bp
from riskr.laboratory import Laboratory

ROOT = Path(__file__).resolve().parent


def create_app(database=None, engine=None):
    app = Flask(__name__)
    app.config.update(SECRET_KEY=secrets.token_hex(32), MAX_CONTENT_LENGTH=16384,
                      SESSION_COOKIE_SAMESITE='Strict', SESSION_COOKIE_HTTPONLY=True)
    path = Path(database or ROOT / 'instance' / 'riskr.sqlite3')
    initialize(path)
    if engine is None:
        lab = Laboratory()
        lab.start()
        engine = ExperimentModel(path, lab)
    app.extensions['engine'] = engine
    app.extensions['model'] = engine
    app.config['DATABASE'] = str(path)

    app.register_blueprint(bp)

    return app


class ProcessLock:
    """Jeden runner na plik bazy; blokada zwalniana również po awarii procesu."""
    def __init__(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.file = path.open('a+b')
        try:
            self.file.seek(0)
            if not self.file.read(1):
                self.file.write(b'0')
                self.file.flush()
            self.file.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.file.close()
            raise SystemExit('RiskR już korzysta z tej bazy. Zatrzymaj poprzedni proces.') from exc

    def close(self):
        self.file.close()


def main():
    parser = argparse.ArgumentParser(description='RiskR — lokalne laboratorium')
    parser.add_argument('command', choices=['init-db','run'])
    parser.add_argument('--database', default=str(ROOT / 'instance' / 'riskr.sqlite3'))
    parser.add_argument('--port', type=int, default=5000)
    args = parser.parse_args()
    path = Path(args.database).resolve()
    if args.command == 'init-db':
        initialize(path)
        print('Baza gotowa. Istniejące dane zostały zachowane.')
        return
    guard = ProcessLock(path.with_suffix('.lock'))
    app = create_app(path)
    engine = app.extensions['engine']

    def close():
        engine.close()
        engine.lab.close()
        guard.close()

    atexit.register(close)
    from waitress import serve
    host = '0.0.0.0' if os.environ.get('RISKR_CONTAINER') == '1' else '127.0.0.1'
    print(f'RiskR: http://127.0.0.1:{args.port}', flush=True)
    serve(app, host=host, port=args.port, threads=8)


if __name__ == '__main__':
    main()
